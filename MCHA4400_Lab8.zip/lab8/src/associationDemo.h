#ifndef ASSOCIATIONDEMO_H
#define ASSOCIATIONDEMO_H

#include "Camera.h"

cv::Mat associationDemo(const Camera & camera, const ChessboardImage & chessboardImage);

#endif