// Tip: Only include headers needed to parse this implementation only
#include <cassert>
#include <Eigen/Core>
#include <Eigen/QR>

#include "gaussian_util.h"

// TODO: Function implementations
