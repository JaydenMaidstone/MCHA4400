#include <doctest/doctest.h>
#include <Eigen/Core>
#include "../../src/gaussian_util.h"

#ifndef CAPTURE_EIGEN
#define CAPTURE_EIGEN(x) INFO(#x " = \n", x.format(Eigen::IOFormat(Eigen::FullPrecision, 0, ", ", ";\n", "", "", "[", "]")));
#endif

SCENARIO("PythagoreanQR")
{
    GIVEN("S1 = I and S2 = 0")
    {
        Eigen::MatrixXd S1, S2;
        // TODO
        REQUIRE(S1.cols() == S2.cols());

        WHEN("pythagoreanQR(S1, S2, S) is called")
        {
            Eigen::MatrixXd S;
            // pythagoreanQR(S1, S2, S);

            THEN("S has expected dimensions")
            {
                // TODO

                AND_THEN("S is upper triangular")
                {
                    // TODO
                }

                AND_THEN("S satisfies S.'*S = S1.'*S1 + S2.'*S2")
                {
                    Eigen::MatrixXd LHS = S.transpose()*S;
                    Eigen::MatrixXd RHS = S1.transpose()*S1 + S2.transpose()*S2;
                    // TODO
                }
            }
        }
    }

    GIVEN("S1 = 0 and S2 = I")
    {
        Eigen::MatrixXd S1, S2;
        // TODO
        REQUIRE(S1.cols() == S2.cols());

        WHEN("pythagoreanQR(S1, S2, S) is called")
        {
            Eigen::MatrixXd S;
            // pythagoreanQR(S1, S2, S);

            THEN("S has expected dimensions")
            {
                // TODO

                AND_THEN("S is upper triangular")
                {
                    // TODO
                }

                AND_THEN("S satisfies S.'*S = S1.'*S1 + S2.'*S2")
                {
                    Eigen::MatrixXd LHS = S.transpose()*S;
                    Eigen::MatrixXd RHS = S1.transpose()*S1 + S2.transpose()*S2;
                    // TODO
                }
            }
        }
    }

    GIVEN("S1 = 3I and S2 = 4I")
    {
        Eigen::MatrixXd S1, S2;
        // TODO
        REQUIRE(S1.cols() == S2.cols());

        WHEN("pythagoreanQR(S1, S2, S) is called")
        {
            Eigen::MatrixXd S;
            // pythagoreanQR(S1, S2, S);

            THEN("S has expected dimensions")
            {
                // TODO

                AND_THEN("S is upper triangular")
                {
                    // TODO
                }

                AND_THEN("S satisfies S.'*S = S1.'*S1 + S2.'*S2")
                {
                    Eigen::MatrixXd LHS = S.transpose()*S;
                    Eigen::MatrixXd RHS = S1.transpose()*S1 + S2.transpose()*S2;
                    // TODO
                }
            }
        }
    }

    GIVEN("S1 and S2 with different numbers of rows")
    {
        Eigen::MatrixXd S1(4,4), S2(1,4);
        // TODO
        REQUIRE(S1.cols() == S2.cols());

        WHEN("pythagoreanQR(S1, S2, S) is called")
        {
            Eigen::MatrixXd S;
            // pythagoreanQR(S1, S2, S);
            
            THEN("S has expected dimensions")
            {
                // TODO

                AND_THEN("S is upper triangular")
                {
                    // TODO
                }

                AND_THEN("S satisfies S.'*S = S1.'*S1 + S2.'*S2")
                {
                    Eigen::MatrixXd LHS = S.transpose()*S;
                    Eigen::MatrixXd RHS = S1.transpose()*S1 + S2.transpose()*S2;
                    // TODO
                }
            }
        }
    }
}
